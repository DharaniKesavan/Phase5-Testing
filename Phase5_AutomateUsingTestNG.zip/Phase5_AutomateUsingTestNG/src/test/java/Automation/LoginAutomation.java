package Automation;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class LoginAutomation {
	
	public WebDriver driver;
	
	@BeforeTest
	public void beforeTest() {
		System.setProperty("webdriver.chrome.driver","E:\\chromedriver_win32\\chromedriver.exe");  
		driver = new ChromeDriver();	  
	}
	
	@Test
	public void login() throws IOException, InterruptedException {	
		driver.get("https://www.browserstack.com/users/sign_in");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		TakesScreenshot ts = (TakesScreenshot)driver;
	    File scr = ts.getScreenshotAs(OutputType.FILE);
	    File Dest = new File("G:\\Phase5_TestNG\\loginPage.png");
	    FileUtils.copyFile(scr, Dest);
		
		driver.findElement(By.id("user_email_login")).sendKeys("dharanikesavan19@gmail.com");
		Thread.sleep(2000);
		TakesScreenshot ts1 = (TakesScreenshot)driver;
	    File scr1 = ts1.getScreenshotAs(OutputType.FILE);
	    File Dest1 = new File("G:\\Phase5_TestNG\\login_email.png");
	    FileUtils.copyFile(scr1, Dest1);
	    
		driver.findElement(By.id("user_password")).sendKeys("dhar@111");
		Thread.sleep(2000);
		TakesScreenshot ts2 = (TakesScreenshot)driver;
	    File scr2 = ts2.getScreenshotAs(OutputType.FILE);
	    File Dest2 = new File("G:\\Phase5_TestNG\\login_password.png");
	    FileUtils.copyFile(scr2, Dest2);
	    
		driver.findElement(By.name("commit")).click();		
		TakesScreenshot ts3 = (TakesScreenshot)driver;
	    File scr3 = ts3.getScreenshotAs(OutputType.FILE);
	    File Dest3 = new File("G:\\Phase5_TestNG\\login_signin.png");
	    FileUtils.copyFile(scr3, Dest3);
	    Thread.sleep(2000);
	}
	
	@AfterTest
	public void afterTest() {
		driver.close();
		System.out.println("Login Test completed Successfully!!!");
	}
}

